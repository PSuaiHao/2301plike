<template>
  <div class="con">
    <el-form ref="loginRef" :model="loginForm" :rules="loginRules">
      <el-form-item prop="mobile">
        <el-input v-model="loginForm.mobile" placeholder="请输入手机号" />
      </el-form-item>
      <el-form-item prop="password">
        <el-input v-model="loginForm.password" placeholder="请输入密码" type="password" show-password />
      </el-form-item>
      <el-form-item prop="isAgree">
        <el-checkbox v-model="loginForm.isAgree"> 请勾选协议 </el-checkbox>
      </el-form-item>
      <el-form-item>
        <el-button type="primary" @click="logins">登录</el-button>
      </el-form-item>
    </el-form>
  </div>
</template>

<script>
// import { login } from '@/api/user';
import { mapActions } from 'vuex'
export default {
  data() {
    const agreeValidator = (rule, value, callback) => {
      value ? callback() : callback(new Error('请勾选协议'))
    }
    return {
      loginForm: {
        mobile: '13800000002',
        password: 'hm#qd@23!',
        isAgree: false
      },
      loginRules: {
        mobile: [
          { required: true, message: '手机号不能为空', trigger: 'blur' },
          { pattern: /^1[3-9]\d{9}$/, message: '格式不正确', trigger: 'blur' }
        ],
        password: [
          { required: true, message: '密码不能为空', trigger: 'blur' },
          { min: 3, max: 12, message: '密码只能是3-12位', trigger: 'blur' }
        ],
        isAgree: [
          { validator: agreeValidator }
        ]
      }
    }
  },
  methods: {
    ...mapActions('user', ['login']),
    async logins() {
      // console.log(this.loginForm);
      await this.$refs.loginRef.validate()
      await this.login(this.loginForm)
      this.$router.push('/')
    }
  },
  computed: {},
  filters: {},
  watch: {},
  components: {}
}
</script>

<style lang="scss" scoped>
.con{
  width: 100%;
  height: 100vh;
  background-image: url(../../../public/日落的多伦多.jpg);
  display: flex;
  justify-content: center;
  align-items: center;
  .el-form{
    width: 600px;
    height: 300px;
    padding: 20px;
    box-sizing: border-box;
  }
}

</style>
