<template>
  <div>
    
    <el-dialog :title="value ? '分配权限':'新增角色'" :visible="isshow" width="40%">
      <!-- 权限分配 -->
      <el-tree
      v-if="value"
        ref="mytree"
        :props="defaultProps"
        :data="permissList"
        show-checkbox
        :default-expand-all="true"
        :default-checked-keys="ids"
        node-key="id"
      >
      </el-tree>
      <!-- 添加角色 -->
      <el-form ref="formRef" :rules="rules" :model="form" label-width="80px" v-else>
  <el-form-item label="角色名称" prop="name">
    <el-input v-model="form.name"></el-input>
  </el-form-item>
  <el-form-item label="启用" prop="state">
    <el-switch
    v-model="form.state"
    :active-value="1"
    :inactive-value="0">
  </el-switch>
  </el-form-item>
  </el-form-item>
  <el-form-item label="角色描述" prop="description">
    <el-input type="textarea" v-model="form.description"></el-input>
  </el-form-item>
</el-form>
      <span slot="footer" class="dialog-footer" style="text-align: center">
        <el-button type="primary" @click="add">确 定</el-button>
        <el-button @click="close">取 消</el-button>
      </span>
    </el-dialog>

    
  </div>
</template>

<script>
import {
  permissRole,
  permissDetail,
  permissEdit,
  addRole,
} from "@/api/role.js";
import { changeData } from "@/utils/index.js";
export default {
  props: {
    isshow: {
      type: Boolean,
      default: false,
    },
    value: {
      type: Number,
      default: null,
    },
  },
  data() {
    return {
      permissList: [],
      defaultProps: {
        label: "name",
        children: "children",
      },
      ids: [],
      form:{
        name:'',
        description:'',
        state:0
      },
      rules: {
          name: [
            { required: true, message: '角色名称不能为空', trigger: 'blur' },
          ],
          description: [
            { required: true, message: '角色描述不能为空', trigger: 'blur' },
          ],
      }
    };
  },
  methods: {
    // 重置表单
    resetForm() {
      this.form = {
        name:'',
        state:0,
        description:''
      }
        this.$refs.formRef.resetFields();
      },
    async add() {
      if(this.value){
        await permissEdit({
        id: this.value,
        permIds: this.$refs.mytree.getCheckedKeys(),
      });
      this.$message.success("分配权限成功");
      
      this.$emit("update:isshow", false);
      this.$emit("input",null)
      }else{
        console.log(11111);
        const res = await addRole(this.form)
        console.log(res,'添加');
        this.$message.success("添加角色成功")
        // 清空表单
        this.resetForm()
        // 通知父组件更新数据
        this.$emit('updateData')
        this.$emit("update:isshow", false);
      }
      
    },
    close() {
      this.$emit("update:isshow", false);
      this.$emit("input",null)
    },
    // 所有权限
    async getPermiss() {
      const result = await permissRole();
      console.log(result, "result");
      this.permissList = changeData(result.data, 0);
    },
    // 默认权限
    async permissDetail(id) {
      const res = await permissDetail(id);
      console.log(res, "detail");
      this.ids = [...res.data.permIds];
    },
  },
  created() {
    // this.getPermiss();
  },
  computed: {},
  filters: {},
  watch: {},
  components: {},
};
</script>

<style lang="scss" scoped></style>
