<template>
  <div class="role">
    <div class="box">
      <el-button class="btn1" size="small" @click="addlist">添加角色</el-button>
      <el-table :data="roleList" border style="width: 100%">
        <el-table-column type="index" label="序号" width="50">
        </el-table-column>
        <el-table-column prop="name" label="角色" width="180">
          <template #default="{ row }">
            <span v-if="!row.isEdit">{{ row.name }}</span>
            <el-input v-else v-model="row.editRow.name" />
          </template>
        </el-table-column>
        <el-table-column prop="state" label="启用" width="180">
          <template v-slot="{ row }">
            <span v-if="!row.isEdit">{{
              row.state == 1 ? "已启用" : "未启用"
            }}</span>
            <el-switch
              v-else
              v-model="row.editRow.state"
              :active-value="1"
              :inactive-value="0"
            />
          </template>
        </el-table-column>
        <el-table-column prop="description" label="描述">
          <template #default="{ row }">
            <span v-if="!row.isEdit">{{ row.description }}</span>
            <el-input
              v-else
              type="textarea"
              v-model="row.editRow.description"
            />
          </template>
        </el-table-column>
        <el-table-column label="操作">
          <template #default="{ row }">
            <div v-if="!row.isEdit">
              <el-button type="text" size="small" @click="permissShow(row.id)"
                >分配权限</el-button
              >
              <el-button type="text" size="small" @click="editOne(row)"
                >编辑</el-button
              >
              <el-popconfirm title="这是一段内容确定删除吗？" @onConfirm="del(row.id)">
                <el-button slot="reference" type="text" size="small"
                  >删除</el-button
                >
              </el-popconfirm>
            </div>
            <div v-else>
              <el-button size="mini" class="btn2" @click="editTwo(row)"
                >确定</el-button
              >
              <el-button size="mini" class="btn3" @click="editCel(row)"
                >取消</el-button
              >
            </div>
          </template>
        </el-table-column>
      </el-table>
      <el-pagination
        style="text-align: center"
        @current-change="handleCurrentChange"
        :current-page.sync="info.page"
        :page-size="info.pagesize"
        layout="total, prev, pager, next"
        :total="info.total"
      >
      </el-pagination>
      <permiss-dialog :isshow.sync="show" @updateData="getRoleList()" v-model="perId" ref="permissRef" />
    </div>
  </div>
</template>

<script>
import permissDialog from "./components/permissDialog.vue";
import { getRoleList, editRole, permissRole, deleteRole } from "@/api/role.js";
export default {
  filters: {},
  components: {
    permissDialog,
  },
  data() {
    return {
      roleList: [],
      info: {
        page: 1,
        pagesize: 5,
        total: 0,
      },
      show: false,
      perId: null,
    };
  },
  computed: {},
  watch: {},
  methods: {
    handleCurrentChange(value) {
      this.info.page = value;
      this.getRoleList();
    },
    async getRoleList() {
      const result = await getRoleList(this.info);
      console.log(result, "role");
      this.roleList = result.data.rows;
      this.info.total = result.data.total;
      this.roleList.forEach((item) => {
        this.$set(item, "isEdit", false);

        this.$set(item, "editRow", {
          name: item.name,
          state: item.state,
          description: item.description,
        });
      });
    },
    // 点击编辑行内回显
    editOne(row) {
      // console.log(132);
      row.isEdit = true;
    },
    // 确认编辑
    async editTwo(row) {
      if (row.editRow.name && row.editRow.description) {
        await editRole({ ...row.editRow, id: row.id });
        this.$message.success("更新成功");
        Object.assign(row, {
          ...row.editRow,
          isEdit: false,
        });
      }
    },
    // 取消编辑
    editCel(row) {
      row.isEdit = false;
    },
    // 分配权限
    async permissShow(id) {
      this.perId = id;
      // await this.$nextTick()
      await this.$refs.permissRef.permissDetail(id);
      await this.$refs.permissRef.getPermiss();
      this.show = true;
    },
    // 删除
    async del(id){
      await deleteRole(id)
      this.$message.success('删除成功！')
      this.getRoleList();
    },
    // 添加
    addlist(){

      this.show = true
    }
  },
  created() {
    this.getRoleList();
  },
};
</script>

<style lang="scss" scoped>
.role {
  padding: 20px;
  box-sizing: border-box;
  background-color:#fff;
}
.btn1 {
  background-color: #2752fb;
  color: white;
}
.el-table {
  margin-top: 20px;
}
.btn2 {
  background-color: #2752fb;
  color: white;
}
.btn3 {
  background-color: #ecf5ff;
  color: #44a0ff;
}
.el-pagination {
  margin-top: 15px;
}
</style>
