<template>
  <div>
    <el-dialog :title="getTitle" :visible="visibleShow" width="40%" center :before-close="handleClose">
      <el-form ref="ruleFormRef" :model="ruleForm" :rules="rules" label-width="100px" class="demo-ruleForm">
        <el-form-item label="部门名称" prop="name">
          <el-input v-model="ruleForm.name" placeholder="2-10个字符" />
        </el-form-item>
        <el-form-item label="部门编码" prop="code">
          <el-input v-model="ruleForm.code" placeholder="2-10个字符" />
        </el-form-item>
        <el-form-item label="部门负责人" prop="managerId">
          <el-select v-model="ruleForm.managerId" placeholder="请选择负责人">
            <el-option v-for="item in options" :key="item.id" :label="item.username" :value="item.id" />
          </el-select>
        </el-form-item>
        <el-form-item label="部门介绍" prop="introduce">
          <el-input v-model="ruleForm.introduce" type="textarea" placeholder="1-100个字符" />
        </el-form-item>
      </el-form>
      <span slot="footer" class="dialog-footer">
        <el-button class="btn1" @click="add">确定</el-button>
        <el-button class="btn2" @click="close">取消</el-button>
      </span>
    </el-dialog>
  </div>
</template>

<script>
import { getDepartment, getDepartmentManger, getDepartmentAdd, getDepartmentEdit, getDepartmentEditTwo, delDepartment } from '@/api/department'
// eslint-disable-next-line no-unused-vars
import { Message } from 'element-ui'
export default {
  filters: {},
  components: {},
  props: {
    visibleShow: {
      type: Boolean,
      default: false
    },
    // eslint-disable-next-line vue/require-default-prop
    departmentId: {
      type: Number || String,
      required: true
    }
  },

  data() {
    const validatePass = async(rule, value, callback) => {
      let { data } = await getDepartment()
      data = data.filter((item) => item.name !== value)
      if (data.some(item => item.name === value)) {
        callback(new Error('部门已经存在该名称了'))
      } else {
        callback()
      }
    }
    const validatePassTwo = async(rule, value, callback) => {
      let { data } = await getDepartment()
      data = data.filter((item) => item.code !== value)
      if (data.some(item => item.code === value)) {
        callback(new Error('部门已经存在该编码了'))
      } else {
        callback()
      }
    }
    return {
      options: [],
      ruleForm: {
        name: '',
        code: '',
        managerId: '',
        introduce: '',
        pid: ''
      },
      rules: {
        name: [
          { required: true, message: '部门名称不能为空', trigger: 'blur' },
          { min: 2, max: 10, message: '长度在 2 到 10 个字符', trigger: 'blur' },
          { validator: validatePass, trigger: 'blur' }
        ],
        code: [
          { required: true, message: '部门名称不能为空', trigger: 'blur' },
          { min: 2, max: 10, message: '长度在 2 到 10 个字符', trigger: 'blur' },
          { validator: validatePassTwo, trigger: 'blur' }
        ],
        introduce: [
          { required: true, message: '部门介绍不能为空', trigger: 'blur' },
          { min: 1, max: 100, message: '长度在 1 到 100 个字符', trigger: 'blur' }
        ]
      }
    }
  },
  computed: {
    getTitle() {
      return this.ruleForm.id ? '编辑部门' : '添加部门'
    }
  },
  watch: {},
  created() {
    this.getManger()
  },
  methods: {
    close() {
      // 重置表单
      this.resetForm()
      this.$emit('update:visibleShow', false)
    },
    resetForm() {
      this.ruleForm = {
        name: '',
        code: '',
        managerId: '',
        introduce: '',
        pid: ''
      }
      this.$refs.ruleFormRef.resetFields()
    },
    async add() {
      await this.$refs.ruleFormRef.validate()
      if (this.ruleForm.id) {
        await getDepartmentEditTwo(this.ruleForm)
        this.$message({
          message: '编辑成功',
          type: 'success'
        })
      } else {
        await getDepartmentAdd({ ...this.ruleForm, pid: this.departmentId })
        this.$message({
          message: '添加成功',
          type: 'success'
        })
      }
      // 通知父组件更新数据
      this.$emit('updateData')
      // 重置表单
      this.resetForm()

      this.$emit('update:visibleShow', false)
    },
    // 删除
    async del() {
      await delDepartment(this.departmentId)
    },
    handleClose() {
      // 重置表单
      this.resetForm()
      this.$emit('update:visibleShow', false)
    },
    async getManger() {
      const result = await getDepartmentManger()
      console.log(result)
      this.options = result.data
    },
    async getDepartEdit() {
      const result = await getDepartmentEdit(this.departmentId)
      console.log(result, 'edit')
      this.ruleForm = result.data
    }
  }
}
</script>

<style lang="scss" scoped>
.el-select {
  width: 100%;
}

.btn1 {
  background-color: #7088eb;
  color: white
}
</style>
