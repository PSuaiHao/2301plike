<template>
  <div class="con">
    <el-tree :data="data" :props="defaultProps" :default-expand-all="true">
      <template #default="{ data }">
        <el-row
          style="width: 100%; height: 45px"
          type="flex"
          justify="space-between"
          align="middle"
        >
          <el-col>{{ data.name }}</el-col>
          <el-col :span="4">
            <span class="tree-manager">{{ data.managerName }}</span>
            <el-dropdown @command="addAndEdit($event, data.id)">
              <span class="el-dropdown-link">
                操作<i class="el-icon-arrow-down el-icon--right" />
              </span>
              <el-dropdown-menu slot="dropdown">
                <el-dropdown-item command="add">添加子部门</el-dropdown-item>
                <el-dropdown-item command="edit">编辑部门</el-dropdown-item>
                <el-dropdown-item command="delete">删除</el-dropdown-item>
              </el-dropdown-menu>
            </el-dropdown>
          </el-col>
        </el-row>
      </template>
    </el-tree>

    <!-- 弹框组件 -->
    <dia-log
      ref="editRef"
      :visible-show.sync="dialogVisible"
      :department-id="departmentId"
      @updateData="getDepartment"
    />
  </div>
</template>

<script>
import { changeData } from '@/utils/index';
import { getDepartment } from "@/api/department";
import diaLog from './components/diaLog.vue';
export default {
  filters: {},
  components: {
    diaLog,
  },
  data() {
    return {
      data: [],
      departmentId: 0, // 父级id
      dialogVisible: false,
      defaultProps: {
        label: "name",
        children: "children",
      },
    };
  },
  computed: {},
  watch: {},
  created() {
    this.getDepartment();
  },
  methods: {
    async getDepartment() {
      const res = await getDepartment();
      console.log(res);
      // debugger
      this.data = changeData(res.data, 0);
    },
    addAndEdit(command, id) {
      console.log(command);
      // 添加
      if (command === "add") {
        // 记录父级id
        this.departmentId = id;
        console.log(this.departmentId, "父级id");
        this.dialogVisible = true;
        // 编辑
      } else if (command === "edit") {
        this.departmentId = id;
        // 更新props是异步动作
        // 而通过ref获取组件实例 调用子组件方法是同步的
        this.$nextTick(() => {
          this.$refs.editRef.getDepartEdit();
        });
        this.dialogVisible = true;
        // 删除
      } else {
        this.departmentId = id;
        this.$nextTick(() => {
          // 父组件删除
          // this.$confirm('此操作将永久删除该文件, 是否继续?', '提示', {
          //   confirmButtonText: '确定',
          //   cancelButtonText: '取消',
          //   type: 'warning'
          // }).then(() => {
          //   delDepartment(this.departmentId).then((res) => {})
          //   this.getDepartment()
          //   this.$message({
          //     type: 'success',
          //     message: '删除成功!'
          //   })
          // }).catch(() => {
          //   this.$message({
          //     type: 'info',
          //     message: '已取消删除'
          //   })
          // })
          // 通过子组件ref方法删除
          this.$confirm("此操作将永久删除该文件, 是否继续?", "提示", {
            confirmButtonText: "确定",
            cancelButtonText: "取消",
            type: "warning",
          })
            .then(() => {
              this.$refs.editRef.del();
              this.getDepartment();
              this.$message({
                type: "success",
                message: "删除成功!",
              });
            })
            .catch(() => {
              this.$message({
                type: "info",
                message: "已取消删除",
              });
            });
        });
      }
    },
  },
};
</script>

<style lang="scss" scoped>
.con {
  padding: 20px;
  box-sizing: border-box;
  background-color: #fff;
}
.tree-manager {
  width: 100px;
  display: inline-block;
}
</style>
