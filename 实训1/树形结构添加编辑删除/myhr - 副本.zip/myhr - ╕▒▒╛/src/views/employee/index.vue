<template>
  <div class="boxs">
    <div class="container">
      <div class="app-container">
        <div class="left">
          <el-input
            v-model="queryparams.keyword"
            type="text"
            prefix-icon="el-icon-search"
            size="small"
            placeholder="输入员工姓名全员搜索"
            @input="search"
          />
          <el-tree
            ref="treeRef"
            :data="data"
            node-key="id"
            :props="defaultProps"
            default-expand-all
            :expand-on-click-node="false"
            :highlight-current="true"
            @current-change="changeNode"
          />
        </div>
        <div class="right">
          <el-row class="opeate-tools" type="flex" justify="end">
            <el-button size="mini" type="primary" @click="goAdd"
              >添加员工</el-button
            >
            <el-button size="mini" @click="importAdd">excel导入</el-button>
            <el-button size="mini" @click="exportAdd">excel导出</el-button>
          </el-row>
          <!-- table列表 -->
          <el-table empty-text="暂无数据" :data="list" style="width: 100%">
            <el-table-column label="头像" prop="staffPhoto">
              <template slot-scope="scope">
                <el-avatar
                  v-if="scope.row.staffPhoto"
                  :src="scope.row.staffPhoto"
                />
                <div v-else class="divOne">
                  {{ scope.row.username.slice(0, 1) }}
                </div>
              </template>
            </el-table-column>
            <el-table-column prop="username" label="姓名" />
            <el-table-column sortable prop="mobile" label="手机号" />
            <el-table-column sortable prop="workNumber" label="工号" />
            <el-table-column prop="formOfEmployment" label="聘用形式">
              <template slot-scope="scope">
                <span>{{
                  scope.row.formOfEmployment == 1 ? "正式" : "非正式"
                }}</span>
              </template>
            </el-table-column>
            <el-table-column prop="departmentName" label="部门" />
            <el-table-column sortable prop="timeOfEntry" label="入职时间" />
            <el-table-column label="操作">
              <template slot-scope="scope">
                <el-button type="text" size="small" @click="edit(scope.row.id)"
                  >查看</el-button
                >
                <el-button type="text" size="small" @click="addle(scope.row.id)">角色</el-button>

                <el-popconfirm
                  title="确认删除该行数据吗？"
                  @onConfirm="delOne(scope.row.id)"
                >
                  <el-button slot="reference" type="text" size="small"
                    >删除</el-button
                  >
                </el-popconfirm>
              </template>
            </el-table-column>
          </el-table>

          <!-- 分页 -->
          <el-row style="height: 60px" align="middle" type="flex" justify="end">
            <el-pagination
              :page-size="queryparams.pagesize"
              layout="total, prev, pager, next"
              :total="total"
              @size-change="handleSizeChange"
              @current-change="handleCurrentChange"
            />
          </el-row>
        </div>
      </div>
      <!-- excel导入组件 -->
      <import-excel :isshow.sync="show" @upData="getEmployeeList" />

      <!-- 分配角色组件 -->
      <employee-Role :uid="uid" :isshow.sync="showRole" ref="erRef" />
    </div>
  </div>
</template>

<script>
import employeeRole from "./components/employeeRole.vue"
import { saveAs } from "file-saver";
import { changeData } from "@/utils/index";
import {
  getEmployeeList,
  exportEmployee,
  deleteEmployee,
} from "@/api/employee";
import { getDepartment } from "@/api/department";
import importExcel from "./components/import-excel.vue";
export default {
  name: "EmployeeName",
  components: {
    importExcel,
    employeeRole
  },
  data() {
    return {
      show: false,
      // 左侧树形菜单
      data: [],
      // 列表数据
      list: [],
      defaultProps: {
        label: "name",
        children: "children",
      },
      // 因为还有很多参数 ，所以在此用对象
      queryparams: {
        departmentId: null,
        page: 1,
        pagesize: 10,
        keyword: "",
      },
      total: 0,
      visible: false,
      showRole:false,
      uid:null
    };
  },
  created() {
    this.getDepart();
  },
  methods: {
    // 导出excel列表
    async exportAdd() {
      const result = await exportEmployee();
      console.log(result, "666");
      saveAs(result, "员工列表.xlsx");
    },
    // 导入
    importAdd() {
      this.show = true;
    },
    // 获取员工数据
    async getEmployeeList() {
      const result = await getEmployeeList(this.queryparams);
      console.log(result, "员工列表数据");
      this.list = result.data.rows;
      this.total = result.data.total;
    },
    async getDepart() {
      const result = await getDepartment();
      this.data = changeData(result.data, 0);

      // 初始化首个节点
      this.queryparams.departmentId = this.data[0].id;
      this.getEmployeeList();
      // 设置选中节点
      // 异步
      this.$nextTick(() => {
        this.$refs.treeRef.setCurrentKey(this.queryparams.departmentId);
      });
    },
    // 搜索
    search() {
      this.getEmployeeList();
    },
    // 进入界面高亮
    changeNode(node) {
      this.queryparams.departmentId = node.id;
      this.getEmployeeList();
    },
    // 分页
    handleSizeChange(value) {
      this.queryparams.pagesize = value;
      this.getEmployeeList();
    },
    handleCurrentChange(value) {
      this.queryparams.page = value;
      this.getEmployeeList();
    },
    // 添加页面
    goAdd() {
      this.$router.push("employee/detail");
    },
    // 查看保存
    edit(id) {
      this.$router.push({ path: "employee/detail", query: { id: id } });
    },
    // 删除
    async delOne(id) {
      // console.log(111);
      const res = await deleteEmployee(id);
      this.$message.success(res.message);
      this.getEmployeeList();
    },
    //角色
    async addle(id){
      this.uid = id
      await this.$refs.erRef.getRoleDetail(id)
      await this.$refs.erRef.getEnabledRoles()
      this.showRole = true
    }
  },
};
</script>

<style lang="scss" scoped>
.boxs {
  padding: 20px;
  box-sizing: border-box;
  background-color: #fff;
}
.app-container {
  background-color: #fff;
  display: flex;
  .left {
    width: 280px;
    border-right: 1px solid #eee;
    .el-tree {
      margin-top: 15px;
    }
  }
  .right {
    flex: 1;
    padding: 20px;
    .opeate-tools {
      margin: 10px;
    }
    .divOne {
      margin-left: 5px;
      text-align: center;
      width: 30px;
      height: 30px;
      line-height: 30px;
      background-color: #04c9be;
      color: white;
      border-radius: 30px;
    }
  }
}
</style>
