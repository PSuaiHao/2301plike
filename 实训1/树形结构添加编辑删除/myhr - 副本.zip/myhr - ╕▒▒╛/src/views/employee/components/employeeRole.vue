<template>
  <div>
    <el-dialog title="分配角色" :visible="isshow" @close="close">
      <el-checkbox-group v-model="checkList">
        <el-checkbox v-for="item in list" :key="item.id" :label="item.id">{{item.name}}</el-checkbox>
      </el-checkbox-group>
      <el-row slot="footer" type="flex" justify="center">
        <el-button @click="btnOk">确定</el-button>
        <el-button>取消</el-button>
      </el-row>
    </el-dialog>
  </div>
</template>

<script>
import { getEnabledRoles,assignRole,getRoleDetail } from "@/api/employee.js"
export default {
  props: {
    isshow: {
      type: Boolean,
      default: false,
    },
    uid:{
        type:Number,
        default:null
    }
  },
  data() {
    return {
      checkList: [],
      list: [],
    };
  },
  methods: {
    close(){
        this.$emit('update:isshow',false)
    },
    // 获取角色数据
    async getEnabledRoles(){
        const res =  await getEnabledRoles()
        console.log(res,'res');
        this.list = res.data
    },
    // 回显
    async getRoleDetail(id){
        const res = await getRoleDetail(id)
        // console.log(res,'12312');
        this.checkList = res.data.roleIds
    },
    async btnOk(){
        const res = assignRole({
            id:this.uid,
            roleIds:this.checkList
        })
        this.$message.success('分配角色成功!')
        this.$emit('update:isshow',false)
    }
  },
  computed: {},
  filters: {},
  watch: {},
  components: {},
};
</script>

<style lang="scss" scoped></style>
