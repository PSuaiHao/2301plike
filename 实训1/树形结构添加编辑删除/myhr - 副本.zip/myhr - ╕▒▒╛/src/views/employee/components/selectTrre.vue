<template>
  <div>
    <el-cascader
      :value="value"
      :options="data"
      :props="defaultProps"
      @change="handleChange"
    />
  </div>
</template>

<script>
import { getDepartment } from '@/api/department'
import { changeData } from '@/utils/index'
export default {
  filters: {},
  components: {},
  props: {
    value: {
      type: Number,
      default: null
    }
  },
  data() {
    return {
      data: [],
      defaultProps: {
        label: 'name',
        value: 'id'
      }
    }
  },
  computed: {},
  watch: {},
  created() {
    this.setData()
  },
  methods: {
    handleChange(value) {
      if (value.length) {
        this.$emit('input', value[value.length - 1])
      } else {
        this.$emit('input', null)
      }
    },
    async setData() {
      const result = await getDepartment()
      console.log(result, 'aaa')
      this.data = changeData(result.data, 0)
    }
  }
}
</script>

<style lang="scss" scoped>

</style>
