<template>
  <div class="div">
    <el-form
      ref="ruleForm"
      :model="ruleForm"
      :rules="rules"
      label-width="100px"
      class="demo-ruleForm"
    >
      <el-form-item label="姓名" prop="username">
        <el-input v-model="ruleForm.username" />
      </el-form-item>
      <el-form-item label="工号" prop="workNumber">
        <el-input v-model="ruleForm.workNumber" disabled />
      </el-form-item>
      <el-form-item label="手机号" prop="mobile">
        <el-input v-model="ruleForm.mobile" />
      </el-form-item>

      <el-form-item label="部门" prop="departmentId">
        <!-- 部门组件 -->
        <selectTrre v-model="ruleForm.departmentId" />
      </el-form-item>
      <el-form-item label="聘用形式" prop="formOfEmployment">
        <el-select
          v-model="ruleForm.formOfEmployment"
          style="width: 100%"
          placeholder="请选择"
        >
          <el-option label="正式" value="1" />
          <el-option label="非正式" value="2" />
        </el-select>
      </el-form-item>
      <el-form-item label="入职时间" required>
        <el-col :span="11" style="width: 100%">
          <el-form-item prop="timeOfEntry" style="width: 100%">
            <el-date-picker
              v-model="ruleForm.timeOfEntry"
              type="date"
              value-format="yyyy-MM-dd"
              placeholder="选择日期"
              style="width: 100%"
            />
          </el-form-item>
        </el-col>
      </el-form-item>
      <el-form-item label="转正时间" required>
        <el-col :span="11" style="width: 100%">
          <el-form-item prop="correctionTime" style="width: 100%">
            <el-date-picker
              v-model="ruleForm.correctionTime"
              type="date"
              placeholder="选择日期"
              style="width: 100%"
            />
          </el-form-item>
        </el-col>
      </el-form-item>
      <el-form-item label="员工头像">
        <!-- 上传头像图片 -->
        <image-upload v-model="ruleForm.staffPhoto" />
      </el-form-item>
      <el-form-item>
        <el-button size="mini" type="primary" @click="add">{{
          id ? "保存更新" : "保存"
        }}</el-button>
      </el-form-item>
    </el-form>
  </div>
</template>

<script>
// import { Message } from 'element-ui'
import selectTrre from './components/selectTrre.vue'
import { addEmployee, updateEmployee, getEmployeeDetail } from '@/api/employee'
import imageUpload from './components/imageUpload.vue'
export default {
  filters: {},
  components: {
    selectTrre,
    imageUpload
  },
  data() {
    const corrTimeValidate = (rule, value, callback) => {
      if (this.ruleForm.timeOfEntry) {
        if (new Date(this.ruleForm.timeOfEntry) > new Date(value)) {
          callback(new Error('转正时间不能小于入职时间'))
          return
        }
      }
      callback()
    }
    return {
      ruleForm: {
        username: '',
        workNumber: '',
        mobile: '',
        staffPhoto: '',
        formOfEmployment: null, // 聘用形式
        departmentId: null, // 部门id
        timeOfEntry: '',
        correctionTime: ''
      },
      rules: {
        username: [{ required: true, message: '请输入姓名', trigger: 'blur' }],
        mobile: [{ required: true, message: '请输入手机号', trigger: 'blur' }],
        departmentId: [
          { required: true, message: '请选择部门', trigger: 'blur' }
        ],
        formOfEmployment: [
          { required: true, message: '请选择聘用形式', trigger: 'blur' }
        ],
        timeOfEntry: [
          { required: true, message: '请选择入职时间', trigger: 'blur' }
        ],
        correctionTime: [
          { required: true, message: '请选择转正时间', trigger: 'blur' },
          { validator: corrTimeValidate, trigger: 'blur' }
        ]
      },
      id: this.$route.query.id
    }
  },
  computed: {},
  watch: {},
  created() {
    this.id && this.getEdit()
  },
  methods: {
    // 添加
    async add() {
      if (this.id) {
        await updateEmployee(this.ruleForm)
        this.$router.push('/employee')
        this.$message({
          message: '修改成功',
          type: 'success'
        })
      } else {
        await addEmployee(this.ruleForm)
        this.$router.push('/employee')
        this.$message({
          message: '添加成功',
          type: 'success'
        })
      }
    },
    // 回显
    async getEdit() {
      const result = await getEmployeeDetail(this.id)
      console.log(result, 'resultEdit')
      this.ruleForm = result.data
    }
  }
}
</script>

<style lang="scss" scoped>
.el-form-item {
  width: 30%;
}
.el-button {
  background-color: #2752fb;
}
.div {
  width: 100%;
  height: 100vh;
  padding: 20px 50px;
}
</style>
