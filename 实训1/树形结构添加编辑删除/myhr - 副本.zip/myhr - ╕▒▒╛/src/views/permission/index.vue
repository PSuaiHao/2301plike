<template>
  <div class="permiss">
    <div class="box">
      <el-button class="btn1" size="small">添加权限</el-button>
      <el-table
        :data="permissList"
        style="width: 100%; margin-bottom: 20px"
        row-key="id"
        border
        default-expand-all
        :tree-props="{ children: 'children', hasChildren: 'hasChildren' }"
      >
        <el-table-column prop="name" label="姓名" width="180">
        </el-table-column>
        <el-table-column prop="code" label="标识" width="180">
        </el-table-column>
        <el-table-column prop="description" label="描述"> </el-table-column>
        <el-table-column label="操作">
          <template slot-scope="scope">
            <el-button type="text" size="small">添加</el-button>
            <el-button type="text" size="small">编辑</el-button>
            <el-button type="text" size="small">删除</el-button>
          </template>
        </el-table-column>
      </el-table>
    </div>
  </div>
</template>

<script>
import { getPermissList } from "@/api/permission.js";
import { changeData } from "@/utils/index.js";
export default {
  filters: {},
  components: {},
  data() {
    return {
      permissList: [],
    };
  },
  computed: {},
  watch: {},
  methods: {
    async getPermissList() {
      const result = await getPermissList();
      console.log(result, "permission");
      this.permissList = changeData(result.data, 0);
    },
  },
  created() {
    this.getPermissList();
  },
};
</script>

<style lang="scss" scoped>
.permiss {
  padding: 20px;
  box-sizing: border-box;
  background-color: #fff;
}
.btn1 {
  background-color: #2752fb;
  color: white;
}
.el-table {
  margin-top: 20px;
}
</style>
