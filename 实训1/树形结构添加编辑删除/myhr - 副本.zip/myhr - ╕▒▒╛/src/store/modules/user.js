import { getToken, setToken, removeToken } from '@/utils/auth'
import { login, getUserInfo } from '@/api/user'
import { constantRoutes } from "@/router/index"
const state = () => {
  return {
    token: getToken(),
    userInfo: {},
    routes:constantRoutes
  }
}

const mutations = {
  getRoutes(state,filterRoutes){
    state.routes = [...constantRoutes,...filterRoutes]
  },
  setToken(state, token) {
    state.token = token
    setToken(token)
  },
  removeToken(state) {
    state.token = null
    removeToken()
  },
  setUserInfo(state, user) {
    state.userInfo = user
  }
}

const actions = {
  async login({ commit }, data) {
    const result = await login(data)
    console.log(result, 'res')
    commit('setToken', result.data)
  },
  async getUserAction({ commit }) {
    console.log(1)
    const result = await getUserInfo()
    console.log(result, 'result')
    commit('setUserInfo', result.data)
    return result.data
  },
  async logout({ commit }) {
    await commit('removeToken')
    await commit('setUserInfo', {})
  }
}

export default {
  namespaced: true,
  state,
  mutations,
  actions
}
