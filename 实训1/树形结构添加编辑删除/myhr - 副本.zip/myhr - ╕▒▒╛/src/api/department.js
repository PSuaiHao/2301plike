import request from '@/utils/request'

// 获取列表数据
export function getDepartment(data) {
  return request({
    url: '/company/department',
    method: 'get',
    data
  })
}

// 获取负责人数据
export function getDepartmentManger(data) {
  return request({
    url: '/sys/user/simple',
    method: 'get',
    data
  })
}

// 添加
export function getDepartmentAdd(data) {
  return request({
    url: '/company/department',
    method: 'POST',
    data
  })
}

// 编辑回显
export function getDepartmentEdit(id) {
  return request({
    url: `/company/department/${id}`,
    method: 'get'
  })
}

// 编辑
export function getDepartmentEditTwo(data) {
  return request({
    url: `/company/department/${data.id}`,
    method: 'PUT',
    data
  })
}

// 删除部门
export function delDepartment(id) {
  return request({
    url: `/company/department/${id}`,
    method: 'DELETE'
  })
}

