import request from '@/utils/request'

// 列表数据
export function getRoleList(params) {
  return request({
    url: '/sys/role',
    params
  })
}
// 确认编辑
export function editRole(data){
  return request({
    url:`/sys/role/${data.id}`,
    method:'put',
    data
  })
}

// 分配权限
export function permissRole(){
  return request({
    url:'/sys/permission'
  })
}

// 角色默认权限
export function permissDetail(id){
  return request({
    url:`/sys/role/${id}`
  })
}

export function permissEdit(data){
  return request({
    url:'/sys/role/assignPrem',
    method:'put',
    data
  })
}

// 删除
export function deleteRole(id){
  return request({
    url:`/sys/role/${id}`,
    method:'delete'
  })
}

// 添加角色
export function addRole(data){
  return request({
    url:`/sys/role`,
    method:'post',
    data
  })
}
