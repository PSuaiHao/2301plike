import request from '@/utils/request'

export function getEmployeeList(params) {
  return request({
    url: '/sys/user',
    method: 'GET',
    params
  })
}

// 新增员工
export function addEmployee(data) {
  return request({
    url: '/sys/user',
    method: 'post',
    data
  })
}
// 根据id查找员工详情
export function getEmployeeDetail(id) {
  return request({
    url: `/sys/user/${id}`
  })
}

// 编辑
export function updateEmployee(data) {
  return request({
    url: `/sys/user/${data.id}`,
    method: 'PUT',
    data
  })
}

export function exportEmployee() {
  return request({
    url: '/sys/user/export',
    responseType: 'blob' // 默认值
  })
}

export function exportTempEmployee() {
  return request({
    url: '/sys/user/import/template',
    responseType: 'blob'
  })
}

export function importEmployee(data) {
  return request({
    url: `sys/user/import`,
    method: 'POST',
    data // formData类型  因为要上传文件
  })
}

export function deleteEmployee(id){
  return request({
    url:`/sys/user/${id}`,
    method:'delete'
  })
}

//获取可用角色
export function getEnabledRoles() {
  return request({
    url: `/sys/role/list/enabled`
  })
}

// 回显
export function getRoleDetail(id){
  return request({
    url:`/sys/user/${id}`
  })
}

// 分配角色
export function assignRole(data) {
  return request({
    url: `/sys/user/assignRoles`,
    method:"PUT",
    data
  })
}
