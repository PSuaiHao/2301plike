import request from "@/utils/request"

export function getPermissList(){
    return request({
        url:'/sys/permission'
    })
}