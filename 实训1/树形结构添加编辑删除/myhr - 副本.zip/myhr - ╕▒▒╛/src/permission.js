import router from './router'
import store from './store'
// import { Message } from 'element-ui'
import NProgress from 'nprogress' // progress bar
import 'nprogress/nprogress.css' // progress bar style
import { getToken } from '@/utils/auth' // get token from cookie
import {myRoutes} from "@/router/index"
// import getPageTitle from '@/utils/get-page-title'

NProgress.configure({ showSpinner: false }) // NProgress Configuration

// 页面鉴权
const whiteList = ['/login', '/404']
router.beforeEach(async (to, from, next) => {
  const token = getToken()
  if (token) {
    if (to.path === '/login') {
      next('/')
    } else {
      if (!store.getters.userId) {
        const result = await store.dispatch('user/getUserAction')
        console.log(result,'99999');
        const filterRoutes = myRoutes.filter((item)=>{
          return result.roles.menus.includes(item.name)
        })
        console.log(filterRoutes,'888888');
        store.commit('user/getRoutes',filterRoutes)
        // 把筛选的路由对象动态添加到路由表中
        router.addRoutes([...filterRoutes,{ path: '*', redirect: '/404', hidden: true }])
        next(to.path)
      }
      next()
    }
  } else {
    if (whiteList.includes(to.path)) {
      next()
    } else {
      next('/login')
    }
  }
})
