import Layout from '@/layout'

export default {
  path: '/',
  component: Layout,
  redirect: '/employee',
  name: 'employee',
  children: [
    {
      path: 'employee',
      name: 'employee',
      component: () => import('@/views/employee/index'),
      meta: { title: '员工管理', icon: 'dashboard' }
    },
    {
      path: 'employee/detail/:id?',
      name: 'detail',
      component: () => import('@/views/employee/detail'),
      hidden: true,
      mata: { title: '添加员工', icon: 'dashboard' }
    }
  ]
}
