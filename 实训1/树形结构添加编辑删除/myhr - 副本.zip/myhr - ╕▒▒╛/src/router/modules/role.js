import Layout from '@/layout'

export default {
  path: '/',
  component: Layout,
  redirect: '/role',
  name: 'role',
  children: [
    {
      path: 'role',
      name: 'role',
      component: () => import('@/views/role/index'),
      meta: { title: '角色管理', icon: 'dashboard' }
    }
  ]
}
