<template>
  <div id="app">
    <router-view />
  </div>
</template>

<style lang="scss">
* {
  padding: 0;
  margin: 0;
  box-sizing: border-box;
}
li {
  list-style: none;
}
a {
  color: inherit; /* 继承父元素的颜色 */
  text-decoration: none; /* 去除下划线 */
}
</style>
