<!-- <template>
	<div>
  <input type="text" v-model="person.xz" @click="changexz">
  <input type="text" v-model="person.age" @click="changeage">
	<button>修改年龄</button>
	<button>修改薪资</button>
	</div>
</template>

<script>
export default {
 data() {
	 return {
		dress:'海南',
		person:{
			name:'张三',
			firstname:'张',
			lastname:'三',
			age:10,
			xz:10k,
			work:'全栈开发'
		}
	 };
 },
 methods: {
	// const p = new (person,{
	// 	get(target,proName){
	// 		console.log(target,'target');
	// 		console.log(proName,'proName');
	// 	},
	// 	set(target,propName,value){
	// 		console.log('修改');
	// 		Reflect.set(target,propName,value)
	// 	},
	// 	deleteProperty(target,propName){
	// 		console.log('删除');
	// 		return Reflect.deleteProperty(target,propName)
	// 	}
	// })
 },





 watch(dress,(newvalue,oldvalue)=>{
	console.log(newvalue,'newvalue');
	console.log(oldvalue,'oldvalue');

 })
};
</script>

<style lang="scss" scoped>

</style> -->